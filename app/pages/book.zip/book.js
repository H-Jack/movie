Page({
  data: {},
  onLoad: function (options) {
    const eventChannel = this.getOpenerEventChannel()
    eventChannel.on('orderint', (res) => {
      this.setData({
        orderint:res.data
      })
    })
  },



  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {


  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  }
})